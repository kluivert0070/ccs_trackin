<?php
include 'qrlib.php'
QRcode::png

?>